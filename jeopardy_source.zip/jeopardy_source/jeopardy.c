#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "questions.h"
#include "players.h"
#include "jeopardy.h"

#define BUFFER_LEN 256
#define NUM_PLAYERS 4

void tokenize(char *input, char **tokens) {
    char *token = strtok(input, " ");
    int i = 0;
    while (token != NULL && i < 3) {
        tokens[i] = token;
        token = strtok(NULL, " ");
        i++;
    }
}

void show_results(player *players, int num_players) {
    for (int i = 0; i < num_players - 1; i++) {
        for (int j = 0; j < num_players - i - 1; j++) {
            if (players[j].score < players[j + 1].score) {
                player temp = players[j];
                players[j] = players[j + 1];
                players[j + 1] = temp;
            }
        }
    }

    printf("\nGame Results:\n");
    for (int i = 0; i < num_players; i++) {
        printf("%d. %s: $%d\n", i + 1, players[i].name, players[i].score);
    }
}

int main() {
    player players[NUM_PLAYERS];
    int num_players = NUM_PLAYERS;
    char buffer[BUFFER_LEN] = {0};

    printf("Welcome to QuizMaster!\n");
    initialize_game();

    for (int i = 0; i < NUM_PLAYERS; i++) {
        printf("Enter player %d's name: ", i + 1);
        fgets(buffer, BUFFER_LEN, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';
        strcpy(players[i].name, buffer);
        players[i].score = 0;
    }

    while (true) {
        display_categories();

        printf("Enter the name of the player selecting the question: ");
        fgets(buffer, BUFFER_LEN, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        char player_name[MAX_LEN];
        strcpy(player_name, buffer);

        if (!player_exists(players, num_players, player_name)) {
            printf("Invalid player name. Try again.\n");
            continue;
        }

        char category[MAX_LEN];
        int value;
        printf("Enter the category: ");
        fgets(category, MAX_LEN, stdin);
        category[strcspn(category, "\n")] = '\0';

        printf("Enter the question value: ");
        fgets(buffer, BUFFER_LEN, stdin);
        value = atoi(buffer);

        if (already_answered(category, value)) {
            printf("This question has already been answered. Choose another.\n");
            continue;
        }

        display_question(category, value);

        printf("Enter your answer (start with 'what is' or 'who is'): ");
        fgets(buffer, BUFFER_LEN, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        if (valid_answer(category, value, buffer)) {
            printf("Correct!\n");
            update_score(players, num_players, player_name, value);
        } else {
            for (int i = 0; i < NUM_QUESTIONS; i++) {
                if (strcmp(questions[i].category, category) == 0 && questions[i].value == value) {
                    printf("Incorrect. The correct answer is: %s\n", questions[i].answer);
                    break;
                }
            }
        }

        for (int i = 0; i < NUM_QUESTIONS; i++) {
            if (strcmp(questions[i].category, category) == 0 && questions[i].value == value) {
                questions[i].answered = true;
                break;
            }
        }

        bool all_answered = true;
        for (int i = 0; i < NUM_QUESTIONS; i++) {
            if (!questions[i].answered) {
                all_answered = false;
                break;
            }
        }

        if (all_answered) {
            break;
        }
    }

    show_results(players, num_players);
    return 0;
}