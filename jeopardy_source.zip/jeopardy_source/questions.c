#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "questions.h"

void initialize_game() {
    strcpy(questions[0].category, "history");
    strcpy(questions[0].question, "Who was the first president of the United States?");
    strcpy(questions[0].answer, "George Washington");
    questions[0].value = 100;
    questions[0].answered = false;

    strcpy(questions[1].category, "history");
    strcpy(questions[1].question, "In which year did World War II end?");
    strcpy(questions[1].answer, "1945");
    questions[1].value = 200;
    questions[1].answered = false;

    strcpy(questions[2].category, "history");
    strcpy(questions[2].question, "Who wrote the Declaration of Independence?");
    strcpy(questions[2].answer, "Thomas Jefferson");
    questions[2].value = 300;
    questions[2].answered = false;

    strcpy(questions[3].category, "history");
    strcpy(questions[3].question, "What was the name of the ship that brought the Pilgrims to America?");
    strcpy(questions[3].answer, "Mayflower");
    questions[3].value = 400;
    questions[3].answered = false;

    strcpy(questions[4].category, "science");
    strcpy(questions[4].question, "What is the chemical symbol for water?");
    strcpy(questions[4].answer, "H2O");
    questions[4].value = 100;
    questions[4].answered = false;

    strcpy(questions[5].category, "science");
    strcpy(questions[5].question, "What is the smallest unit of life?");
    strcpy(questions[5].answer, "Cell");
    questions[5].value = 200;
    questions[5].answered = false;

    strcpy(questions[6].category, "science");
    strcpy(questions[6].question, "What planet is known as the Red Planet?");
    strcpy(questions[6].answer, "Mars");
    questions[6].value = 300;
    questions[6].answered = false;

    strcpy(questions[7].category, "science");
    strcpy(questions[7].question, "What is the speed of light?");
    strcpy(questions[7].answer, "299792458 m/s");
    questions[7].value = 400;
    questions[7].answered = false;

    strcpy(questions[8].category, "movies");
    strcpy(questions[8].question, "Who directed the movie 'Inception'?");
    strcpy(questions[8].answer, "Christopher Nolan");
    questions[8].value = 100;
    questions[8].answered = false;

    strcpy(questions[9].category, "movies");
    strcpy(questions[9].question, "What is the highest-grossing film of all time?");
    strcpy(questions[9].answer, "Avatar");
    questions[9].value = 200;
    questions[9].answered = false;

    strcpy(questions[10].category, "movies");
    strcpy(questions[10].question, "Who played the role of Jack in 'Titanic'?");
    strcpy(questions[10].answer, "Leonardo DiCaprio");
    questions[10].value = 300;
    questions[10].answered = false;

    strcpy(questions[11].category, "movies");
    strcpy(questions[11].question, "What year was the first 'Star Wars' movie released?");
    strcpy(questions[11].answer, "1977");
    questions[11].value = 400;
    questions[11].answered = false;
}

void display_categories() {
    printf("Available Categories and Questions:\n");
    for (int i = 0; i < NUM_CATEGORIES; i++) {
        printf("%s:\n", categories[i]);
        for (int j = 0; j < NUM_QUESTIONS / NUM_CATEGORIES; j++) {
            int index = i * (NUM_QUESTIONS / NUM_CATEGORIES) + j;
            if (!questions[index].answered) {
                printf("  $%d\n", questions[index].value);
            }
        }
    }
}

void display_question(char *category, int value) {
    for (int i = 0; i < NUM_QUESTIONS; i++) {
        if (strcmp(questions[i].category, category) == 0 && questions[i].value == value) {
            printf("Question: %s\n", questions[i].question);
            return;
        }
    }
    printf("Question not found.\n");
}

bool valid_answer(char *category, int value, char *answer) {
    for (int i = 0; i < NUM_QUESTIONS; i++) {
        if (strcmp(questions[i].category, category) == 0 && questions[i].value == value) {
            char *token = strtok(answer, " ");
            while (token != NULL) {
                if (strcmp(token, "is") == 0) {
                    token = strtok(NULL, " ");
                    if (token != NULL && strcmp(token, questions[i].answer) == 0) {
                        return true;
                    }
                } else if (strcmp(token, questions[i].answer) == 0) {
                    return true;
                }
                token = strtok(NULL, " ");
            }
        }
    }
    return false;
}

bool already_answered(char *category, int value) {
    for (int i = 0; i < NUM_QUESTIONS; i++) {
        if (strcmp(questions[i].category, category) == 0 && questions[i].value == value) {
            return questions[i].answered;
        }
    }
    return false;
}