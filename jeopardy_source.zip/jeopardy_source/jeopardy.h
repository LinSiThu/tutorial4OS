#ifndef JEOPARDY_H_
#define JEOPARDY_H_

#define MAX_LEN 256

void tokenize(char *input, char **tokens);
void show_results(player *players, int num_players);

#endif /* JEOPARDY_H_ */